# Colors

- background color: #E9F5FA

# Typography

- Oswald - https://fonts.google.com/specimen/Oswald?query=oswald
- Krona One - https://fonts.google.com/specimen/Krona+One?query=krona+
