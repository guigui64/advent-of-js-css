# Typography

- Roboto Mono -

# Colors

- Pink: #FF00C7

# Photography

- sherman-yang-VBBGigIuaDY-unsplash.jpg - Photo by [Sherman Yang](https://unsplash.com/@emp_creative?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText) on [Unsplash](https://unsplash.com/?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText)
- - Photo by [Jakob Owens](https://unsplash.com/@jakobowens1?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText) on [Unsplash](https://unsplash.com/?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText)
- finding-dan-dan-grinwis-O35rT6OytRo-unsplash.jpg Photo by [Dan Grinwis](https://unsplash.com/@finding_dan?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText) on [Unsplash](https://unsplash.com/?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText)
- vincentiu-solomon-ln5drpv_ImI-unsplash.jpg - Photo by [Vincentiu Solomon](https://unsplash.com/@vincentiu?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText) on [Unsplash](https://unsplash.com/?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText)
- silas-baisch-Wn4ulyzVoD4-unsplash.jpg - Photo by [Silas Baisch](https://unsplash.com/@silasbaisch?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText) on [Unsplash](https://unsplash.com/?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText)
- dave-hoefler-okUIdo6NxGo-unsplash.jpg - Photo by [Dave Hoefler](https://unsplash.com/@davehoefler?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText) on [Unsplash](https://unsplash.com/?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText)
- eugene-golovesov-EXdXp7Z4X4w-unsplash.jpg - Photo by [Eugene Golovesov](https://unsplash.com/@eugene_golovesov?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText) on [Unsplash](https://unsplash.com/?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText)
- jennifer-reynolds-\_8HI5xf4TkE-unsplash.jpg - Photo by [Jennifer reynolds](https://unsplash.com/@jenreyn0lds?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText) on [Unsplash](https://unsplash.com/?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText)
- kellen-riggin-SIBOiXKg0Ds-unsplash.jpg - Photo by [Kellen Riggin](https://unsplash.com/@kalaniparker?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText) on [Unsplash](https://unsplash.com/?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText)
- rafael-hoyos-weht-zhkAp8DGkxw-unsplash.jpg - Photo by [Rafael Hoyos](https://unsplash.com/@rhweht?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText)a[=](ref="https://unsplash.com/?utm_source=unsplash&utm_medium=referral&utm_conte)itCopyText">Unsplash</a>
- sonya-romanovska-wzdXhyi3AiM-unsplash.jpg - Photo by [Sonya Romanovska](https://unsplash.com/@sonya_romanovska?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText) on [Unsplash](https://unsplash.com/?utm_source=unsplash&utm_medium=referral&utm_content=creditCopyText)
