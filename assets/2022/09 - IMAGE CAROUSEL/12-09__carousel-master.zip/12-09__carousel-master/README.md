Users should be able to 
- toggle left and right through the image thumbnails
- click an image to select it manually