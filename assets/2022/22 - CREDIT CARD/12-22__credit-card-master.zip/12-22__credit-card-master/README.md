# Brief

In this project, we're going to create a credit card form.

You can use as many (or as few) tools, libraries, and frameworks as you'd like. If you're trying to learn something new, this would be a great way to push yourself.

# Users should be able to:

- When the user finishes (blur) entering a credit card number, change the credit card image to match the type of card they entered. You can add a class of `visa`, `mastercard`, `discover`, or `american` to line 16 in index.html
  - American Express cards always begin with the number 3- more specifically 34 or 37.
  - Visa cards begin with the number 4.
  - Mastercards start with the number 5.
  - Discover Cards begin with the number 6.
- When the user enters the CVV number, have the card flip over by adding a class of `flip` on line 16 in index.html

# Need some support on this challenge?

- Upgrade to the [Solution Tier](https://www.adventofjs.com/)**.** You'll get a video explanation from James.
- Join the [Learn Build Teach Discord](http://learnbuildteach.com) community. We have a separate channel set up specifically for the Advent of JavaScript.

# Getting Started

1. To get started, [download the zip file](https://store.selfteach.me/products/home). This includes all the project assets you need to get started: HTML, CSS, images, and fonts.
2. Take a look around. Look at the project's Figma file. This is a great way to see how the pieces and parts should look within the browser.
3. Open the project's `README.md` file. It has additional information on how the project is structured.
4. Customize your project/file architecture to your liking.
5. Happy coding!
6. Once you're finished, share your work using **#adventofjs**

# Taking your Project to the Next Level

- Use a framework like [React](http://react.com), [Vue](https://vuejs.org/), or [Svelte](https://svelte.dev/). Or, if you're feeling particularly adventurous, try writing everything in Vanilla JavaScript.
- Take a step back and try writing the HTML and CSS for this project yourself. Start with the provided Figma file. If you get stuck, consider purchasing the [Advent of CSS](https://click.convertkit-mail.com/e5u4nz4nq7a0umqw04a8/kkhmh2u86pkdoefl/aHR0cDovL2FkdmVudG9mY3NzLmNvbQ==) solutions, where Amy explains exactly how to build this.

# FAQs

- Can I use libraries/frameworks on these projects?
  - Of course! We're providing the vanilla HTML and CSS, but you can use whatever tools and frameworks you'd like.
- Oh no! I'm stuck!
  - Check out the [Learn Build Teach Discord.](http://learnbuildteach.com) We have a specific channel set up, just for the Advent of JavaScript.
- Can I use this project in my portfolio?
  - Sure! But, be honest about the work that *you* did
