# Fonts

- Courer Prime - https://fonts.google.com/specimen/Courier+Prime?query=courier+prime
- Roboto - https://fonts.google.com/specimen/Roboto
- Beth Ellen - https://fonts.google.com/specimen/Beth+Ellen?query=beth+ellen

# Colors

- background color - #FBE6DB
- submit button - #7D193E
- border color - #E0E0E0
