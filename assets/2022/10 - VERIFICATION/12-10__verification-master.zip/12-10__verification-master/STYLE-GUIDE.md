# Typography

- Source Sans Pro - https://fonts.google.com/specimen/Source+Sans+Pro

# Colors

- Background color: #FFFFFF
- Heading Text Color: #6778E8
- Input Text Color: #6778E8;
- Input background color: #F0F3FA;
- Button Gradient: `linear-gradient(93.32deg, #8D9EFF -10.93%, #A674FB 113.82%)`
