# Fonts

- Roboto - https://fonts.google.com/specimen/Roboto
- Roboto Mono - https://fonts.google.com/specimen/Roboto+Mono?query=roboto+monos

# Colors

- Yellow - #FBFF00
- Purple - #8d58ff
