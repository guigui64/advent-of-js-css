# Typography

- Oswald - https://fonts.google.com/specimen/Oswald?query=oswald
- Roboto - https://fonts.google.com/specimen/Roboto

# Colors

- Pink: #f40082
- Yellow: #FFD200
- Purple: #3452a5;
