# Fonts

- Roboto - https://fonts.google.com/specimen/Roboto

# Colors

- primary color - #363DAA
- selected sort arrow - #363DAA
- unselected sort arrow - #DDE8F7
- border color - #DDE8F7
- input field background - #EDF4F9
