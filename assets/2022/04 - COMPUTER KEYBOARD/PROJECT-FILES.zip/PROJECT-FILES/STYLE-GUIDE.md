# Colors

- Keyboard Background #F6F6F6
- Gold - #ffd200
- Teal - #60C1B6
- Gray - #868888

# Fonts

- Inter - https://fonts.google.com/specimen/Inter
