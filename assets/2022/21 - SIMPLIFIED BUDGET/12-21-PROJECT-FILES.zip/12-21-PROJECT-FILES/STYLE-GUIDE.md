# Typography

- Poppins - https://fonts.google.com/specimen/Poppins

# Colors

- Primary, Lime Green: #51F129
- Gray Labels - #8E909D
- Input background - #323645
- Add Panel - #282A37
- Positive number - #4CA536
- Negative number - #DF1414
